Updated Sponge screen:
- pause / continue animation button
- slower explanation timing
- message-byte preview from the text typed in Step 2
- map highlights XOR, Keccak-f, and squeezing during animation
- padding theory text improved
