Fixed sponge animation accuracy:
- Message block is still XORed only with the rate part.
- Orange capacity path now visually goes into Keccak-f together with rate.
- Text explains: capacity is not XORed, but it is included in the full 1600-bit state passed to Keccak-f.
