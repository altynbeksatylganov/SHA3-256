MainProject SHA3-256 Trainer
Open index.html in browser.
Files: index.html, style.css, app.js.
Internet is needed for GSAP CDN animation library.
